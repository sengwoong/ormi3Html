const container = document.getElementById('container');
const addBoxButton = document.getElementById('addBoxBtn');
const deleteBoxButton = document.getElementById('deleteBoxBtn');
const changeColorButton = document.getElementById('changeColorBtn');
let isDragging = false;
let initialX, initialY;
let currentClickedBox = null;

// Load box information from local storage when the page loads
const boxInfoJSON = localStorage.getItem('boxInfo');
let windowJSON = localStorage.getItem('windowInfo');
let savedBoxInfoMap = boxInfoJSON ? JSON.parse(boxInfoJSON) : {};


let savedWidowInfoMap = windowJSON ? JSON.parse(windowJSON) : {};

function windowResizeInfo() {
    console.log("window.innerWidth")
    console.log(window.innerWidth)
    let x=  window.innerWidth
    let y=  window.innerHeight
    windowInfo={
        windowX : x ,
        windowY : y
    }
    savedWidowInfoMap = windowInfo; 
  
    localStorage.setItem('windowInfo', JSON.stringify(windowInfo));
}

addEventListener("load", () => {
    windowResizeInfo()
});


function updateAndSaveBoxInfo(boxElement) {
  const boxId = boxElement.id;
  const boxInfo = {
    x: boxElement.style.left,
    y: boxElement.style.top,
    color: boxElement.style.backgroundColor,
    content: boxElement.innerText
  };

  savedBoxInfoMap[boxId] = boxInfo;

  localStorage.setItem('boxInfo', JSON.stringify(savedBoxInfoMap));
}

function createNewBox() {
  const newBox = document.createElement('div');
  const boxId = Date.now().toString(); // Create a unique ID using timestamp
  newBox.id = boxId;
  newBox.classList.add('box');
  newBox.innerText = "Double Click to Edit"; // Initial content
  newBox.addEventListener('dblclick', handleBoxDoubleClick); // Add double click event listener
  container.appendChild(newBox);

  updateAndSaveBoxInfo(newBox);
}

function handleBoxDoubleClick(event) {
  const boxElement = event.target;
  const newContent = prompt('Enter new content:', boxElement.innerText);
  if (newContent !== null) {
    boxElement.innerText = newContent;
    updateAndSaveBoxInfo(boxElement);
  }
}

savedBoxInfoMap = Object.entries(savedBoxInfoMap).reduce((acc, [boxId, boxInfo]) => {
  const newBox = document.createElement('div');
  newBox.id = boxId;
  newBox.classList.add('box');
  newBox.innerText = boxInfo.content;
  newBox.style.left = boxInfo.x;
  newBox.style.top = boxInfo.y;
  newBox.style.backgroundColor = boxInfo.color;
  newBox.addEventListener('dblclick', handleBoxDoubleClick); // Add double click event listener
  container.appendChild(newBox);

  acc[boxId] = boxInfo;
  return acc;
}, {});

container.addEventListener('mousedown', (event) => {
  if (event.target.classList.contains('box')) {
    currentClickedBox = event.target;
  }
  isDragging = true;
  currentClickedBox.style.cursor = 'grabbing';
  initialX = event.clientX;
  initialY = event.clientY;
});

document.addEventListener('mousemove', (e) => {
  if (!isDragging) return;

  const distanceX = e.clientX - initialX;
  const distanceY = e.clientY - initialY;

  const newTop = currentClickedBox.offsetTop + distanceY;
  const newLeft = currentClickedBox.offsetLeft + distanceX;

  currentClickedBox.style.top = newTop + 'px';
  currentClickedBox.style.left = newLeft + 'px';
  initialX = e.clientX;
  initialY = e.clientY;
});

document.addEventListener('mouseup', () => {
  if (isDragging) {
    isDragging = false;
    if (currentClickedBox) {
      currentClickedBox.style.cursor = 'grab';
      updateAndSaveBoxInfo(currentClickedBox);
    }
  }
});

addBoxButton.addEventListener('click', createNewBox);

deleteBoxButton.addEventListener('click', () => {
  if (currentClickedBox) {
    currentClickedBox.remove();
    currentClickedBox = null;

    const boxId = currentClickedBox.id;
    delete savedBoxInfoMap[boxId];
    localStorage.setItem('boxInfo', JSON.stringify(savedBoxInfoMap));
  }
});

changeColorButton.addEventListener('click', () => {
  if (currentClickedBox) {
    const colors = ['red', 'blue', 'green', 'yellow', 'purple'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    currentClickedBox.style.backgroundColor = randomColor;

    updateAndSaveBoxInfo(currentClickedBox);
  }
});


// ...

// Add a function to handle window resize
function handleWindowResize() {
    for (const boxId in savedBoxInfoMap) {
      const boxInfo = savedBoxInfoMap[boxId];

      console.log(savedWidowInfoMap)
      const CureentwindowX = savedWidowInfoMap["windowX"]
      const CureentwindowY = savedWidowInfoMap["windowY"]
      console.log(
        CureentwindowX>window.innerWidth
      )
      console.log(
        CureentwindowY>window.innerHeight
      )
   
      
      
      let newX 
      let newY


      const boxElement = document.getElementById(boxId);
      CureentwindowX>window.innerWidth?
       newX = parseInt(boxInfo.x)  - 15
       :  newX = parseInt(boxInfo.x)  + 15
       ;

       CureentwindowY>window.innerHeight?
       newY = parseInt(boxInfo.y)  - 15
       : parseInt(boxInfo.y)  + 15
       ;
  
      boxElement.style.left = newX + 'px';
      boxElement.style.top = newY + 'px';
  
      updateAndSaveBoxInfo(boxElement);
    }
  }
  
  // Attach the window resize event handler
  window.addEventListener('resize', ()=>{
    handleWindowResize(),
    windowResizeInfo()
  }
  );
  
