const preloaderBtns = document.querySelectorAll(".preloader__btn");
const preloaderHideThreshold = 18;

function setPreloaderStyle(button, scale) {
  button.style.transform = `scale(${scale})`;
  button.querySelector(".preloader__btn_hold").style.opacity =
    1 - (scale - 1) / preloaderHideThreshold;
}

preloaderBtns.forEach((preloaderBtn) => {
  let intervalId = null;
  let scale = 1;
  let isButtonClicked = false;

  preloaderBtn.addEventListener("mousedown", () => {
    if (!isButtonClicked) {
      isButtonClicked = true;
      intervalId = setInterval(() => {
        scale += 0.175;
        setPreloaderStyle(preloaderBtn, scale);
        if (scale >= 1 + preloaderHideThreshold) {
          clearInterval(intervalId);

          // 위 버튼일 때는 해당 URL로 이동
          if (preloaderBtn.classList.contains("preloader__btn--top")) {
            window.location.href = "http://127.0.0.1:5500/analyze/index.html";
          }

          // 아래 버튼일 때는 해당 URL로 이동
          if (preloaderBtn.classList.contains("preloader__btn--bottom")) {
            window.location.href = "http://127.0.0.1:5500/todo/index.html";
          }
        }
      }, 10);
    }
  });

  preloaderBtn.addEventListener("mouseup", () => {
    if (isButtonClicked) {
      clearInterval(intervalId);
      intervalId = setInterval(() => {
        scale -= 0.075;
        if (scale < 1) {
          scale = 1;
        }
        setPreloaderStyle(preloaderBtn, scale);
        if (scale <= 1) {
          clearInterval(intervalId);
          isButtonClicked = false;
        }
      }, 10);
    }
  });
});
